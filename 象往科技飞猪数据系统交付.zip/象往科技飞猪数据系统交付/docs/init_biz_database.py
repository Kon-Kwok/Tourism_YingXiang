#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
初始化象往科技飞猪数据业务数据库
注意：配置层用JSON文件，数据库只存业务数据！
"""

import json
import pymysql


class BizDatabaseInitializer:
    def __init__(self, config_path="config.json"):
        self.config_path = config_path
        self.config = None
        self.conn = None

    def load_config(self):
        print("[1/5] 加载配置文件...")
        with open(self.config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        print("   [OK]")
        return True

    def connect_mysql(self):
        print("[2/5] 连接MySQL...")
        mysql_config = self.config['mysql']
        self.conn = pymysql.connect(
            host=mysql_config['host'],
            port=mysql_config['port'],
            user=mysql_config['user'],
            password=mysql_config['password'],
            charset=mysql_config['charset'],
            cursorclass=pymysql.cursors.DictCursor
        )
        print("   [OK]")
        return True

    def create_database(self):
        print("[3/5] 创建数据库...")
        with self.conn.cursor() as cursor:
            cursor.execute("DROP DATABASE IF EXISTS xiangwang_fliggy_system")
            cursor.execute("""
                CREATE DATABASE xiangwang_fliggy_system
                DEFAULT CHARACTER SET utf8mb4
                DEFAULT COLLATE utf8mb4_unicode_ci
            """)
            cursor.execute("USE xiangwang_fliggy_system")
        print("   [OK] 数据库: xiangwang_fliggy_system")
        return True

    def create_biz_tables(self):
        print("[4/5] 创建业务表...")

        tables_sql = [
            # ========== 数据采集批次表（用于关联） ==========
            """
            CREATE TABLE IF NOT EXISTS spider_data_batch (
                id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
                page_id VARCHAR(100) NOT NULL COMMENT '页面ID(对应JSON配置)',
                page_name VARCHAR(200) COMMENT '页面名称',
                batch_start_time TIMESTAMP NULL COMMENT '采集开始时间',
                batch_end_time TIMESTAMP NULL COMMENT '采集结束时间',
                status VARCHAR(20) DEFAULT 'pending' COMMENT '状态: pending/running/success/failed',
                error_message TEXT COMMENT '错误信息',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                INDEX idx_page_id (page_id),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据采集批次表'
            """,

            # ========== 赤兔名品数据 ==========
            """
            CREATE TABLE IF NOT EXISTS biz_customer_service_daily (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                stat_date DATE NOT NULL COMMENT '统计日期',
                customer_service VARCHAR(100) NOT NULL COMMENT '客服姓名',
                incoming_count INT COMMENT '接入人数',
                avg_response_time_sec DECIMAL(8,2) COMMENT '平均响应时间(秒)',
                complaint_count INT COMMENT '差评数',
                consult_to_booking_success_rate DECIMAL(5,4) COMMENT '咨询->预订成功率',
                offline_count INT COMMENT '离线次数',
                complaint_review_count INT COMMENT '差评复核数',
                customer_satisfaction_score DECIMAL(5,2) COMMENT '客户满意度',
                transfer_count INT COMMENT '转接数',
                hangup_count INT COMMENT '挂起数',
                first_response_count INT COMMENT '首次响应数',
                supplement_count INT COMMENT '补充数',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_stat_date (stat_date),
                INDEX idx_customer_service (customer_service),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服数据日报表'
            """,

            """
            CREATE TABLE IF NOT EXISTS biz_customer_service_weekly (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                stat_week VARCHAR(50) NOT NULL COMMENT '统计周',
                customer_service VARCHAR(100) COMMENT '客服姓名',
                incoming_count INT COMMENT '接入人数',
                avg_response_time_sec DECIMAL(8,2) COMMENT '平均响应时间(秒)',
                complaint_count INT COMMENT '差评数',
                consult_to_booking_success_rate DECIMAL(5,4) COMMENT '咨询->预订成功率',
                offline_count INT COMMENT '离线次数',
                complaint_review_count INT COMMENT '差评复核数',
                customer_satisfaction_score DECIMAL(5,2) COMMENT '客户满意度',
                transfer_count INT COMMENT '转接数',
                hangup_count INT COMMENT '挂起数',
                first_response_count INT COMMENT '首次响应数',
                supplement_count INT COMMENT '补充数',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_stat_week (stat_week),
                INDEX idx_customer_service (customer_service),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服数据周报表'
            """,

            """
            CREATE TABLE IF NOT EXISTS biz_cs_workload_log (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                customer_service VARCHAR(100) COMMENT '客服姓名',
                operation_time DATETIME COMMENT '操作时间',
                operation_type VARCHAR(50) COMMENT '操作类型',
                info_source VARCHAR(100) COMMENT '信息来源',
                remark TEXT COMMENT '备注',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_customer_service (customer_service),
                INDEX idx_operation_time (operation_time),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服工作量分析表'
            """,

            # ========== Ali-Trip Agent Performance ==========
            """
            CREATE TABLE IF NOT EXISTS biz_agent_performance_daily (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                agent_name VARCHAR(100) NOT NULL COMMENT 'Agent名称',
                consult_count INT COMMENT '咨询人数',
                incoming_count INT COMMENT '接入人数',
                direct_incoming_count INT COMMENT '直接接入人数',
                conversion_count INT COMMENT '转化人数',
                conversion_amount DECIMAL(14,2) COMMENT '转化金额',
                order_message_count INT COMMENT '订单消息数',
                refund_message_count INT COMMENT '退款消息数',
                customer_msg_count INT COMMENT '客服消息数',
                in_chat_time_sec INT COMMENT '在线时长(秒)',
                max_concurrent_chats INT COMMENT '最大同时接待数',
                pending_response_count INT COMMENT '未回复消息数',
                responded_count INT COMMENT '已回复消息数',
                avg_response_count INT COMMENT '平均回复数',
                first_response_sec INT COMMENT '首次响应(秒)',
                avg_response_sec DECIMAL(8,2) COMMENT '平均响应(秒)',
                total_response_time_sec INT COMMENT '总响应时长(秒)',
                stat_date DATE COMMENT '统计日期',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_agent_name (agent_name),
                INDEX idx_stat_date (stat_date),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent绩效日报表'
            """,

            """
            CREATE TABLE IF NOT EXISTS biz_agent_sales_daily (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                agent_name VARCHAR(100) NOT NULL COMMENT 'Agent名称',
                consult_count INT COMMENT '咨询人数',
                incoming_count INT COMMENT '接入人数',
                booking_count INT COMMENT '预订人数',
                sales_amount DECIMAL(14,2) COMMENT '销售金额',
                order_count INT COMMENT '订单数',
                adult_count INT COMMENT '成人人数',
                child_count INT COMMENT '儿童人数',
                stat_date DATE COMMENT '统计日期',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_agent_name (agent_name),
                INDEX idx_stat_date (stat_date),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent销售日报表'
            """,

            # ========== 飞猪订单数据 ==========
            """
            CREATE TABLE IF NOT EXISTS biz_fliggy_store_daily (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                stat_date DATE NOT NULL COMMENT '统计日期',
                total_pv BIGINT COMMENT 'Total PV',
                total_uv BIGINT COMMENT 'Total UV',
                free_source_uv BIGINT COMMENT '免费来源UV',
                platform_source_uv BIGINT COMMENT '平台来源UV',
                direct_product_uv BIGINT COMMENT '直达商品UV',
                chat_volume INT COMMENT 'Chat Volume',
                total_bookings INT COMMENT 'Total Bookings',
                total_pax INT COMMENT 'Total PAX',
                gmv DECIMAL(14,2) COMMENT 'GMV',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_stat_date (stat_date),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='飞猪店铺每日关键数据表'
            """,

            """
            CREATE TABLE IF NOT EXISTS biz_fliggy_order_daily (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                data_batch_id BIGINT COMMENT '关联批次ID',
                stat_date DATE NOT NULL COMMENT '统计日期',
                pv BIGINT COMMENT 'PV',
                uv BIGINT COMMENT 'UV',
                paid_uv BIGINT COMMENT 'Paid UV',
                new_customer_count INT COMMENT '新客人数',
                gmv DECIMAL(14,2) COMMENT 'GMV',
                consult_count INT COMMENT '咨询量',
                consult_conversion_rate DECIMAL(8,4) COMMENT '咨询转化率',
                new_order_count INT COMMENT '新订单数',
                new_order_conversion_rate DECIMAL(8,4) COMMENT '新订单转化率',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_stat_date (stat_date),
                INDEX idx_data_batch_id (data_batch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='飞猪订单每日数据表'
            """
        ]

        with self.conn.cursor() as cursor:
            for sql in tables_sql:
                cursor.execute(sql)
        print(f"   [OK] 业务表创建成功 ({len(tables_sql)} 张)")
        return True

    def verify(self):
        print("[5/5] 验证...")
        tables = [
            'spider_data_batch',
            'biz_customer_service_daily',
            'biz_customer_service_weekly',
            'biz_cs_workload_log',
            'biz_agent_performance_daily',
            'biz_agent_sales_daily',
            'biz_fliggy_store_daily',
            'biz_fliggy_order_daily',
        ]
        with self.conn.cursor() as cursor:
            cursor.execute("USE xiangwang_fliggy_system")
            for table in tables:
                cursor.execute(f"SHOW TABLES LIKE '{table}'")
                if cursor.fetchone():
                    print(f"   [OK] {table}")
        return True

    def close(self):
        if self.conn:
            self.conn.close()

    def run(self):
        print("\n" + "=" * 60)
        print("  象往科技飞猪业务数据库初始化")
        print("  (配置用JSON文件，数据库只存业务数据)")
        print("=" * 60 + "\n")

        try:
            if not self.load_config():
                return False
            if not self.connect_mysql():
                return False
            if not self.create_database():
                return False
            if not self.create_biz_tables():
                return False
            if not self.verify():
                return False

            print("\n" + "=" * 60)
            print("  [OK] 业务数据库初始化完成!")
            print("  数据库名: xiangwang_fliggy_system")
            print("=" * 60)
            return True

        except Exception as e:
            print(f"\n[FAIL] {e}")
            import traceback
            traceback.print_exc()
            return False
        finally:
            self.close()


if __name__ == "__main__":
    init = BizDatabaseInitializer()
    success = init.run()
    import sys
    sys.exit(0 if success else 1)
